Extract this folder, then run: php install.php /absolute/path/to/pivot
CLI only. Preserves private config, database and uploads. Keeps cron for retries.
